
#ifndef _kinderiv_h
#define _kinderiv_h

/* data used to construct this file */

/* declarations */

namespace coreneuron {

/* callback indices */

/* switch cases */

#define _NRN_DERIVIMPLICIT_CASES \


#define _NRN_DERIVIMPLICIT_NEWTON_CASES \


#define _NRN_KINETIC_CASES \


#define _NRN_EULER_CASES \


#endif

} //namespace coreneuron
