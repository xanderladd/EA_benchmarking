class Neuron:
	pass
