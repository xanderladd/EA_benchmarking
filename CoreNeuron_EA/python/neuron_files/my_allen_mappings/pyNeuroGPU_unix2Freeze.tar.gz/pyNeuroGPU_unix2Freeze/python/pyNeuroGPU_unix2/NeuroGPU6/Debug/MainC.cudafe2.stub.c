#define __NV_MODULE_ID _13_MainC_cpp1_ii_debugFN
#define __NV_CUBIN_HANDLE_STORAGE__ extern
#include "crt/host_runtime.h"
#include "MainC.fatbin.c"
